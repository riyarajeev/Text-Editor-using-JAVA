TEXT EDITOR
Any word processing program that allows you to type and edit text is referred to as a text editor. 
An "empty" display screen with a fixed-line length and visible line numbers is provided by a text editor. 

1. OVERVIEW:
The application is created using JAVA programming language and the IDE used is Apache NetBeans 12.3. 
In the text editor, I have given a text area and two buttons for ‘Open’ and ‘Save’ in the menu bar. 
The window can also be minimized, maximized and closed.

2. PROBLEM STATEMENT:
To create a JAVA application -Text Editor by incorporating the Data Structures & Algorithms concepts and to present the output of the program. 

3. PROBLEM SOLUTION:
-> I have created the application using NetBeans IDE.
-> The language used to create is JAVA.
-> I have used JFrame to show the output of the program which looks similar to a text editor.
-> The text editor consists of two functions (i) Open and (ii) Save.
(i) Open- opens an existing file.
(ii) Save- saves the changes made to the file.

4.SOFTWARE REQUIREMENTS:
->IDE - Apache NetBeans 12.3
->OS - Windows 10

5.MODULES:
Step 1 – Importing relevant Libraries
Step 2 – Design prototype of text editor
Step 3 – Button 1 Function (Open)
Step 4 – Button 2 Function (Save)
Step 5 – Write Main program
Step 6 – Run the program
Step 7 – Error correction
Step 8 – Get the Output

